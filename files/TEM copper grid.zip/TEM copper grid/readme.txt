This dataset contains five 2D images from a material object called 
"TEM copper grid" and its 3D surface model (.off format). The set of 
2D images were obtained by tilting the SEM specimen stage 7 degrees 
from one to the next in the image sequence.

http://selibcv.org/3dsem/