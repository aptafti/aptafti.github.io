% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
function integralImage = getIntegralImage( image )
%GETINTEGRALIMAGE Summary of this function goes here
%   Detailed explanation goes here

    cumulativeSum = cumsum( cumsum( double(image), 1 ), 2 );
    integralImage = padarray( cumulativeSum, [1 1], 0, 'pre' );
    
end
