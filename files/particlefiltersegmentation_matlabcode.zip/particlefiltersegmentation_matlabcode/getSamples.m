% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
function features = getSamples( image, mask )
%GETPREDICTORS Summary of this function goes here
%   Detailed explanation goes here

    integralImage = getIntegralImage( image );
    
    borderIndexes = find( mask == 10 );
    n = size( borderIndexes, 1 );
    
    features = zeros( 5*n, 15 );
    
    for i = 1:n
        [ y, x ] = ind2sub( size( image ), borderIndexes(i) );
        
        features( i, 1:14) = getHaarFeatures( integralImage, x, y );
        features( i, 15 ) = 1;
    end
    
    % make the border pixels unselectable by the random neg. feat.
    % selector
    mask(1:4,:) = ones( 4, size(mask,2) );
    mask(end-3:end, :) = ones( 4, size(mask,2) );
    mask( :, 1:4 ) = ones( size(mask,1), 4 );
    mask( :, end-3:end ) = ones( size(mask,1), 4 );
    
    nonborderIndexes = find( mask == 0 );

    % random indexes
    for j = n+1:5*n
        m = size( nonborderIndexes, 1 );
        
        random = floor( rand(1) * (m-1) ) + 1;
        
        index = nonborderIndexes( random );
        
        nonborderIndexes = [ nonborderIndexes( 1:random-1 ); nonborderIndexes( random+1:end ) ];
        
        [ y, x ] = ind2sub( size( image ), index );
        
        features( j, 1:14) = getHaarFeatures( integralImage, x, y );
        features( j, 15 ) = 0;
    end
    
end
