% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
function PixelSum=GetSumRect(IntegralImage,x,y,Width,Height)
%
% PixelSum=GetSumRect(IntegralImage,x,y,Width,Height)
%
%IIWidth=size(IntegralImage,1);
%PixelSum  =   IntegralImage((x+Width)*IIWidth + y + Height+1) + ...
%			  IntegralImage(x*IIWidth+y+1) - ...
%			  IntegralImage((x+Width)*IIWidth+y+1) - ...
%			  IntegralImage(x*IIWidth+y+Height+1);

% A  B
% D  C
% I(C) + I(A) - I(B) - I(D)
PixelSum = IntegralImage( y + Height, x + Width ) + ...
           IntegralImage( y, x ) - ...
           IntegralImage( y, x + Width ) - ...
           IntegralImage( y + Height, x );


            
       