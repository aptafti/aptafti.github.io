% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
for i = 1:20
    figure, PlotIt_Orig( images{30 + i}, landmarks(:,:,30 + i), optimParamsets{i}, S_struct );
end
