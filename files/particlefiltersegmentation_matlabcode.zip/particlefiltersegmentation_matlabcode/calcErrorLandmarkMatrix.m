% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% gets the per landmark error matrix of the test images

error_landmark = zeros(64, 20);
for i = 1:20
    error_landmark(:,i) = ErrorPerLandmark( landmarks(:,:,30 + i), optimParamsets{i}, S_struct );
end
