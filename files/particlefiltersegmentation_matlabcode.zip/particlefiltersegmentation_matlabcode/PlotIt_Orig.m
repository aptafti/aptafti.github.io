%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function:         PlotIt(FVr_temp,iter,S_struct)
% Author:           Rainer Storn
% Description:      PlotIt can be used for special purpose plots
%                   used in deopt.m.
% Parameters:       FVr_temp     (I)    Paramter vector
%                   iter         (I)    counter for optimization iterations
%                   S_Struct     (I)    Contains a variety of parameters.
%                                       For details see Rundeopt.m
% Return value:     -
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function PlotIt_Orig(img, landmarks, FVr_temp, S_struct )
    meanShape = S_struct.meanShape;
    PC = S_struct.PC;

    T = [ cos(FVr_temp(11)), -sin(FVr_temp(11)), FVr_temp(9) ; ...
          sin(FVr_temp(11)),  cos(FVr_temp(11)), FVr_temp(10) ; ...
          0,                  0,                 1 ];
    
    shape = genShape( meanShape, PC,  [ FVr_temp(12), 0; 0 FVr_temp(13) ], FVr_temp(1:8), T );
 
  imshow(img), hold on, 
  plot( shape(:,1), shape(:,2), 'y', 'LineWidth', 2 );
  plot( landmarks(:,1), landmarks(:,2), 'b', 'LineWidth', 2 );
  
  
  drawnow;
  pause(1); %wait for one second to allow convenient viewing
  return
