%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function:         PlotIt(FVr_temp,iter,S_struct)
% Author:           Rainer Storn
% Description:      PlotIt can be used for special purpose plots
%                   used in deopt.m.
% Parameters:       FVr_temp     (I)    Paramter vector
%                   iter         (I)    counter for optimization iterations
%                   S_Struct     (I)    Contains a variety of parameters.
%                                       For details see Rundeopt.m
% Return value:     -
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function PlotIt(FVr_temp,iter,S_struct)
    probMap = S_struct.probMap;
    meanShape = S_struct.meanShape;
    PC = S_struct.PC;

    T = [ cos(FVr_temp(11)), -sin(FVr_temp(11)), FVr_temp(9) ; ...
          sin(FVr_temp(11)),  cos(FVr_temp(11)), FVr_temp(10) ; ...
          0,                  0,                 1 ];
    
  shape = genShape( meanShape, PC, [ FVr_temp(12), 0; 0 FVr_temp(13) ], FVr_temp(1:8), T );
 
  imagesc(probMap), colormap(gray), hold on,
  plot( shape(:,1), shape(:,2), 'y', 'LineWidth', 3 );
  plot( shape(1:40,1), shape(1:40,2), 'b+', 'LineWidth', 3 );
  plot( shape(52:end,1), shape(52:end,2), 'b+', 'LineWidth', 3 );
  plot( shape(41:51,1), shape(41:51,2), 'r+', 'LineWidth', 3 );
  
  drawnow;
  pause(1); %wait for one second to allow convenient viewing
  return
