% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
function P = probMap( image, B )
P = zeros( size(image,1), size(image, 2) );

integralImage = getIntegralImage( image );

X=zeros( ( size(image,2)-9 ) * (size(image,1)-9), 14 );

k = 1;
for i = 5:size(image,1)-5
    disp(['row ' num2str(i) '/' num2str(size(image,1)-5) ] );
    for j = 5:size(image,2)-5
        X(k, :) = getHaarFeatures( integralImage, j, i );
        k = k + 1;
    end
end


size(X)

[ labels, scores ] = predict( B, X );

k = 1;
for i = 5:size(image,1)-5
    disp(['row_2 ' num2str(i) '/' num2str(size(image,1)-5) ] );
    for j = 5:size(image,2)-5
        P(i,j) = scores(k,2);
        k = k + 1;
    end
end
