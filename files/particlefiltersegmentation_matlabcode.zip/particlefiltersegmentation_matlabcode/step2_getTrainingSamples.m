% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% gets the features of the first 30 images
samples = [];
for i = 1:30
    disp( [ 'processing ' num2str(i) ] );
    samples = [samples; getSamples( images{i}, masks{i} ) ];
end
