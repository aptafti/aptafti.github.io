% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
function features = getHaarFeatures( integralImage, cx, cy )


    dx = [ 0, 0, 0, 1, -1, -1, -1, 1, -2, -2, -2, 1, -3, -3, -3, 1, ...
            -1, 0, 1, -1, -1, -1, -2, 0, 2, -2, -2, -2, -4, -1, 2, -4, -4, -4 ];
        
    dy = [ 0, 1, 0, 0, -1, 1, -1, -1, -2, 1, -2, -2, -3, 1, -3, -3, ...
             -1, -1, -1, -1, 0, 1, -2, -2, -2, -2, 0, 2, -4, -4, -4, -4, -1, 2 ];
    
    w = [ 2, 2, 1, 1, 4, 4, 2, 2, 6, 6, 3, 3, 8, 8, 4, 4, ...
          1, 1, 1, 3, 3, 3, 2, 2, 2, 6, 6, 6, 3, 3, 3, 9, 9, 9 ];
      
    h = [ 1, 1, 2, 2, 2, 2, 4, 4, 3, 3, 6, 6, 4, 4, 8, 8, ...
          3, 3, 3, 1, 1, 1, 6, 6, 6, 2, 2, 2, 9, 9, 9, 3, 3, 3 ];
    
    j = 1;
    features=zeros(1,14);
    for i = 1:2:15
        features(1,j) = getSumRect( integralImage, cx + dx(i), cy + dy(i), w(i), h(i) ) - ...
                      getSumRect( integralImage, cx + dx(i+1), cy + dy(i+1), w(i+1), h(i+1) ); 
        j = j + 1;   
    end
    
    for i = 17:3:32
        features(1,j) = getSumRect( integralImage, cx + dx(i), cy + dy(i), w(i), h(i) ) - ...
                      getSumRect( integralImage, cx + dx(i+1), cy + dy(i+1), w(i+1), h(i+1) ) + ...
                      getSumRect( integralImage, cx + dx(i+2), cy + dy(i+2), w(i+2), h(i+2) );
        j = j + 1;       
    end
end