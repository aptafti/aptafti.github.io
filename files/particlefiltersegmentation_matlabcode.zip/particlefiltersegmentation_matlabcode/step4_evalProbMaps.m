% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% evaluate the probability maps for the test samples

PM = cell( 1,20 );
for i = 31:50
    disp( [ 'processing image ' num2str(i) ] );
    PM{i - 30} = probMap( images{i}, B );
end
