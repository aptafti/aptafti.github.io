% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% step 3: train the treebagger
X = samples(:,1:14);
Y = samples(:,15);

B = TreeBagger( 32, X, Y );
