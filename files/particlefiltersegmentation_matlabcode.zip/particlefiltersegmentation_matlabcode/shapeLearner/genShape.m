% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% generates a shape 
% meanShape is a 1x128 matrix containing the mean shape (x1,y1,x2,y2,...)
% PC is the principal components matrix (128x128)
% S is a 1x2 scaling vector (the scaling factors sx, sy)
% b is the 1x128 matrix of parameters
% T is a 3x3 homogeneous transformation matrix
function shape = genShape( meanShape, PC, S, b, T )

% generate the 'normalized' shape using the parameters
normShape = meanShape + b * PC';

% reformat the shape for 
normShape2 = reshape(normShape, 2, 64);

% apply the scaling on the normshape
normShapeScaled2 = S * normShape2;

% apply T homog. transformation on the scaled normalized shape
normShapeScaled2H = [ normShapeScaled2; ones(1, 64) ];
shape = (T * normShapeScaled2H)';
shape = shape( :, 1:2);

