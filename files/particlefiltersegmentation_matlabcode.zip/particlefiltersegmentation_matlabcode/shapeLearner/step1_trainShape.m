% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% converts the data format to pca compatible matrix (30 shapes)
D=preprocess(aligned);

% calculate the mean
meanD = mean(D');

% get the mean "subtract" matrix
meanD2 = repmat(meanD, 30, 1)';

% demean the data (get the differences)
demeanD = D - meanD2;

% do the PCA on the differences
[signals, PC, V] = pca2(demeanD);

% generate a new shape from the mean
%rS = meanD + 5 * PC(:,1)';

% reformat the shape so that it's easily viewable
%rS2 = reshape(rS', 64, 2);

% plot the new shape
%plot( rS2(:,1), rS2(:,2), 'g+' );


% plot the mean
%rmeanD = reshape(meanD, 2, 64)';
%plot( rmeanD(:,1), rmeanD(:,2), 'r' );

