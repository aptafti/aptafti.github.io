% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% reshape our matrix "aligned" to pca compatible format (first 30 samples)
function D = preprocess( aligned )

D=[];
for i = 1:30
    B = reshape(aligned(:,:,i)', 128, 1);
    D = [ D, B ];
end
