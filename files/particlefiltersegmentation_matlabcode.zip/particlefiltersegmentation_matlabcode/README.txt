Particle Filter Segmentation
----------------------------------------

This directory contains the scripts that were used to implement the particle filter
segmentation project in MATLAB.

This document provides a few guidelines on how to reproduce the results and how to
run the optimizer.

1. Setting up the environment

 In order the run the scripts properly, the MATLAB working directory has to be set to
 the main project directory. The subdirectories 'DeMat' and 'shapeLearner' have to be
 added to the MATLAB path.

2. Input data

 For a clean start, the input data has to be read from the 'handdata.mat' file.
 To quickly reproduce the results, the 'particles_optim.mat' file is needed.
 
3. Training the shape model

 The script 'shapeLearner/step1_trainShape.m' can be used to train the
 shape model on the aligned input data (first 30 samples).
 The output is the mean-shape and the matrix of the principal components and the
 vector of the eigenvalues associated with the PC components.
 
4. Extract the training samples for the pixel classification

 The script 'step2_getTrainingSamples.m' extracts the positive and
negative training samples for the random forest algorithm by evaluating
the Haar-like features on every boundary pixel, and a set of random
non-boundary pixels. It creates the 'samples' variable as an output.

5. Train the Random Forest using treebagger

 The script 'step3_traintree.m' prepares the parameters for the TreeBagger
trainer function from the 'samples' variable, and calculates the
forest (using 32 trees) into the variable 'B'. ('B' is the internal structure in MATLAB
that defines the random forest, and is used later at the evaluation step.)

6. Generation of the probability maps

 The script 'step4_evalProbMaps.m' is used to calculate the probability
maps for the test images. (the last 20 image in the input dataset.)
The resulting probability maps are stored in the PM cell.
( PM{1} -> map for images{31} 
  ...
  PM{20} -> map for images{50} )

7. Executing the Differential Evolution algorithm

 The DE algorithm is executed by the 'runDE.m' script. This script
contains a hard-coded parameter, that defines the current probability
map on which the algorithm works.

 In order to start the optimization eg. on the 5th test image:
 type 'PM_current = PM{5};'
 type 'runDE'
 
 By default, the script will execute a differential evolution optimization
 using a boundary set refined for the test images, and it will stop
 after 1500 iteration or after reaching a 95% or higher probability.
 (Actually it always stopped on the iteration count, and never reached
  the 95% percent probability.)
  
 In every 10th iteration, the best member of the current population is
visualized. 


Other infos, additional steps

Cost Function
-------------

The cost function for the optimization is implemented in the 'objfun.m'
matlab function.
It generates the shape based on the current parameters and evaluates
the mean of the individual pixel probabilities.
In order to make it a minimization cost function, the final cost function
is 1.0 - mean_probability.


Visualizing the results
-----------------------

By using the 'PlotIt( images{i}, landmarks{i}, optimParamsets{i - 30}, S_struct )'
call it is possible to visualize the original image with the resulting
shape of our optimization + the landmarks.

We have also calculated a landmark-based error statistic using the
'calcErrorLandMarkMatrix.m' script + boxplot on the transpose of the
resulting matrix.

