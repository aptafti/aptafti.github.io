% Authors: Z. B�rdosi, A. Pahlavan Tafti, D. Granata, G. Lugos, S. Saxena
% returns the mse error on each landmark between 2 shapes
% landmarks - landmark shape
% FVr_temp - shape and transform parameters for a generated shape
% S_struct - DE optimization structure containing the PC components and
%            meanshape
function error_mse = ErrorPerLandmark( landmarks, FVr_temp, S_struct )
    meanShape = S_struct.meanShape;
    PC = S_struct.PC;

    T = [ cos(FVr_temp(11)), -sin(FVr_temp(11)), FVr_temp(9) ; ...
          sin(FVr_temp(11)),  cos(FVr_temp(11)), FVr_temp(10) ; ...
          0,                  0,                 1 ];
    
    shape = genShape( meanShape, PC,  [ FVr_temp(12), 0; 0 FVr_temp(13) ], FVr_temp(1:8), T );
 
  %figure, hold on
  %plot( shape(:,1), shape(:,2), 'y', 'LineWidth', 2 );
  %plot( landmarks(:,1), landmarks(:,2), 'b', 'LineWidth', 2 );
  
  
error = shape - landmarks;
error_mse = sqrt(sum(error .* error, 2));
