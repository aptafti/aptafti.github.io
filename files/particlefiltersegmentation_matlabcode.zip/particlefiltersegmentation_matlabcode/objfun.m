%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function:         S_MSE= objfun(FVr_temp, S_struct)
% Author:           Rainer Storn
% Description:      Implements the cost function to be minimized.
% Parameters:       FVr_temp     (I)    Paramter vector
%                   S_Struct     (I)    Contains a variety of parameters.
%                                       For details see Rundeopt.m
% Return value:     S_MSE.I_nc   (O)    Number of constraints
%                   S_MSE.FVr_ca (O)    Constraint values. 0 means the constraints
%                                       are met. Values > 0 measure the distance
%                                       to a particular constraint.
%                   S_MSE.I_no   (O)    Number of objectives.
%                   S_MSE.FVr_oa (O)    Objective function values.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function S_MSE = objfun( FVr_temp, S_struct )

    probMap = S_struct.probMap;
    meanShape = S_struct.meanShape;
    PC = S_struct.PC;

    T = [ cos(FVr_temp(11)), -sin(FVr_temp(11)), FVr_temp(9) ; ...
          sin(FVr_temp(11)),  cos(FVr_temp(11)), FVr_temp(10) ; ...
          0,                  0,                 1 ];
    
    shape = genShape( meanShape, PC, [ FVr_temp(12), 0; 0 FVr_temp(13) ], FVr_temp(1:8), T );

    sum = 0;
    % Calculate the cost function.
    for i = 1:64
        %imshow(probMap), hold on, plot( shape(:,1), shape(:,2) )
        
        y = round(shape( i, 2 ));
        x = round(shape( i, 1 ));
        
        if ( x < 1 || x > size(probMap,2) || y < 1 || y > size(probMap,1) )
            %disp('warning: point out of image, assuming 0 probability');
        else
            sum = sum + probMap( y, x );
        end
    end

    F_cost_tol = sum / 64;
    
    %isp( [ 'cost: ' num2str(F_cost_tol) ] );
    
    % Strategy to put everything into a cost function.
    S_MSE.I_nc      = 0; %no constraints
    S_MSE.FVr_ca    = 0; %no constraint array
    S_MSE.I_no      = 1; %number of objectives (costs)
    S_MSE.FVr_oa(1) = 1.0 - F_cost_tol;
end